--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1 (Debian 16.1-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Postleitzahlen; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public."Postleitzahlen" (
    id integer NOT NULL
);


ALTER TABLE public."Postleitzahlen" OWNER TO main;

--
-- Name: TokenUsage; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public."TokenUsage" (
    id integer NOT NULL,
    token_id integer NOT NULL,
    date timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resource_hash character varying(6) NOT NULL,
    payload_length integer NOT NULL,
    response_length integer NOT NULL,
    response_success boolean NOT NULL,
    response_code integer NOT NULL
);


ALTER TABLE public."TokenUsage" OWNER TO main;

--
-- Name: TokenUsage_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public."TokenUsage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TokenUsage_id_seq" OWNER TO main;

--
-- Name: TokenUsage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public."TokenUsage_id_seq" OWNED BY public."TokenUsage".id;


--
-- Name: VerbrauchsausweisGewerbe; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public."VerbrauchsausweisGewerbe" (
    id integer NOT NULL,
    uid uuid NOT NULL,
    gebaeude_stammdaten_id integer NOT NULL,
    rechnungen_id integer,
    benutzer_id integer NOT NULL
);


ALTER TABLE public."VerbrauchsausweisGewerbe" OWNER TO main;

--
-- Name: VerbrauchsausweisWohnen; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public."VerbrauchsausweisWohnen" (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    gebaeude_stammdaten_id integer NOT NULL,
    benutzer_id integer NOT NULL,
    rechnungen_id integer,
    erstellungsdatum timestamp(6) without time zone,
    ausstellgrund character varying,
    registriernummer character varying,
    erledigt boolean,
    baujahr_heizung integer[],
    zusaetzliche_heizquelle boolean,
    brennstoff_1 character varying(50),
    einheit_1 character varying(10),
    brennstoff_2 character varying(50),
    einheit_2 character varying(10),
    startdatum timestamp(6) without time zone,
    enddatum timestamp(6) without time zone,
    verbrauch_1 integer,
    verbrauch_2 integer,
    verbrauch_3 integer,
    verbrauch_4 integer,
    verbrauch_5 integer,
    verbrauch_6 integer,
    warmwasser_enthalten boolean,
    anteil_warmwasser_1 double precision,
    anteil_warmwasser_2 double precision
);


ALTER TABLE public."VerbrauchsausweisWohnen" OWNER TO main;

--
-- Name: VerbrauchsausweisWohnen_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public."VerbrauchsausweisWohnen_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VerbrauchsausweisWohnen_id_seq" OWNER TO main;

--
-- Name: VerbrauchsausweisWohnen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public."VerbrauchsausweisWohnen_id_seq" OWNED BY public."VerbrauchsausweisWohnen".id;


--
-- Name: adressen; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.adressen (
    id integer NOT NULL,
    benutzer_id integer NOT NULL,
    empfaenger_zeile_1 character varying NOT NULL,
    empfaenger_zeile_2 character varying,
    strasse character varying(100) NOT NULL,
    plz character varying(5) NOT NULL,
    ort character varying(50) NOT NULL,
    geolocation character varying,
    uid uuid DEFAULT gen_random_uuid()
);


ALTER TABLE public.adressen OWNER TO main;

--
-- Name: adressen_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.adressen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.adressen_id_seq OWNER TO main;

--
-- Name: adressen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.adressen_id_seq OWNED BY public.adressen.id;


--
-- Name: anteilshaber; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.anteilshaber (
    id integer NOT NULL,
    benutzer_id integer NOT NULL,
    gebaeude_id integer NOT NULL,
    rolle character varying,
    privilegien bigint,
    uid uuid
);


ALTER TABLE public.anteilshaber OWNER TO main;

--
-- Name: anteilshaber_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.anteilshaber_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anteilshaber_id_seq OWNER TO main;

--
-- Name: anteilshaber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.anteilshaber_id_seq OWNED BY public.anteilshaber.id;


--
-- Name: bedarfsausweis_wohnen; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.bedarfsausweis_wohnen (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    gebaeude_stammdaten_id integer NOT NULL,
    benutzer_id integer NOT NULL,
    rechnungen_id integer,
    ausweisart character varying NOT NULL,
    erstellungsdatum timestamp(6) without time zone,
    ausstellgrund character varying NOT NULL,
    registriernummer character varying,
    erledigt boolean,
    saniert boolean,
    baujahr integer[],
    einheiten integer,
    wohnflaeche integer,
    keller_beheizt boolean,
    dachgeschoss_beheizt integer,
    lueftungskonzept character varying,
    leerstand real,
    versorgungssysteme integer,
    fenster_dach integer,
    energiequelle_2_nutzung integer,
    daemmung integer,
    anzahl_vollgeschosse integer,
    geschosshoehe double precision,
    anzahl_gauben integer,
    breite_gauben double precision,
    masse_a double precision,
    masse_b double precision,
    masse_c double precision,
    masse_d double precision,
    masse_e double precision,
    masse_f double precision,
    fensterflaeche_so_sw double precision,
    fensterflaeche_nw_no double precision,
    aussenwandflaeche_unbeheizt double precision,
    dachflaeche double precision,
    deckenflaeche double precision,
    dach_u_wert double precision,
    decke_u_wert double precision,
    aussenwand_flaeche double precision,
    aussenwand_u_wert double precision,
    fussboden_flaeche double precision,
    fussboden_u_wert double precision,
    volumen double precision,
    dicht boolean,
    fenster_flaeche_1 double precision,
    fenster_art_1 double precision,
    fenster_flaeche_2 double precision,
    fenster_art_2 double precision,
    dachfenster_flaeche double precision,
    dachfenster_art double precision,
    haustuer_flaeche double precision,
    haustuer_art double precision,
    dach_bauart character varying,
    decke_bauart character varying,
    dach_daemmung double precision,
    decke_daemmung double precision,
    aussenwand_daemmung double precision,
    boden_daemmung double precision,
    aussenwand_bauart character varying,
    boden_bauart character varying,
    warmwasser_verteilung character varying,
    warmwasser_speicherung character varying,
    warmwasser_erzeugung character varying,
    heizung_zentral boolean,
    heizung_verteilung character varying,
    heizung_speicherung character varying,
    waerme_erzeugung_heizung character varying,
    anteil_zusatzheizung double precision,
    kollektor_flaeche double precision,
    vanw_stromverbrauch_enthalten double precision,
    wird_gekuehlt boolean
);


ALTER TABLE public.bedarfsausweis_wohnen OWNER TO main;

--
-- Name: bedarfsausweis_wohnen_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.bedarfsausweis_wohnen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bedarfsausweis_wohnen_id_seq OWNER TO main;

--
-- Name: bedarfsausweis_wohnen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.bedarfsausweis_wohnen_id_seq OWNED BY public.bedarfsausweis_wohnen.id;


--
-- Name: benutzer; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.benutzer (
    id integer NOT NULL,
    name character varying(50),
    vorname character varying(50),
    email character varying(255) NOT NULL,
    passwort character varying(255) NOT NULL,
    profilbild character varying,
    benutzer_adresse_id integer,
    rechnung_adresse_id integer,
    versand_adresse_id integer,
    uid uuid
);


ALTER TABLE public.benutzer OWNER TO main;

--
-- Name: benutzer_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.benutzer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.benutzer_id_seq OWNER TO main;

--
-- Name: benutzer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.benutzer_id_seq OWNED BY public.benutzer.id;


--
-- Name: documenttemplates; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.documenttemplates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    shortdescription character varying(100) NOT NULL,
    longdescription character varying(5000) NOT NULL,
    user_id integer NOT NULL,
    is_private boolean DEFAULT true NOT NULL,
    documenttype integer NOT NULL,
    filename character varying(100) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.documenttemplates OWNER TO main;

--
-- Name: documenttemplates_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.documenttemplates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documenttemplates_id_seq OWNER TO main;

--
-- Name: documenttemplates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.documenttemplates_id_seq OWNED BY public.documenttemplates.id;


--
-- Name: documenttypes; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.documenttypes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    shortdescription character varying(100) NOT NULL,
    longdescription character varying(5000) NOT NULL
);


ALTER TABLE public.documenttypes OWNER TO main;

--
-- Name: documenttypes_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.documenttypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documenttypes_id_seq OWNER TO main;

--
-- Name: documenttypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.documenttypes_id_seq OWNED BY public.documenttypes.id;


--
-- Name: gebaeude_bilder; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.gebaeude_bilder (
    id integer NOT NULL,
    gebaeude_stammdaten_id integer NOT NULL,
    kategorie character varying NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.gebaeude_bilder OWNER TO main;

--
-- Name: gebaeude_bilder_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.gebaeude_bilder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gebaeude_bilder_id_seq OWNER TO main;

--
-- Name: gebaeude_bilder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.gebaeude_bilder_id_seq OWNED BY public.gebaeude_bilder.id;


--
-- Name: gebaeude_plaene; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.gebaeude_plaene (
    id integer NOT NULL,
    gebaeude_stammdaten_id integer NOT NULL,
    uid uuid NOT NULL
);


ALTER TABLE public.gebaeude_plaene OWNER TO main;

--
-- Name: gebaeude_plaene_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.gebaeude_plaene_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gebaeude_plaene_id_seq OWNER TO main;

--
-- Name: gebaeude_plaene_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.gebaeude_plaene_id_seq OWNED BY public.gebaeude_plaene.id;


--
-- Name: gebaeude_stammdaten; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.gebaeude_stammdaten (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    benutzer_id integer,
    gebaeude_adresse_id integer,
    gebaeudetyp character varying,
    gebaeudeteil character varying,
    baujahr_gebaeude integer[],
    baujahr_heizung character varying,
    baujahr_klima character varying,
    einheiten integer,
    flaeche integer,
    saniert boolean,
    keller integer,
    dachgeschoss integer,
    lueftung character varying(50),
    kuehlung character varying(50),
    leerstand integer
);


ALTER TABLE public.gebaeude_stammdaten OWNER TO main;

--
-- Name: gebaeude_stammdaten_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.gebaeude_stammdaten_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gebaeude_stammdaten_id_seq OWNER TO main;

--
-- Name: gebaeude_stammdaten_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.gebaeude_stammdaten_id_seq OWNED BY public.gebaeude_stammdaten.id;


--
-- Name: klimafaktoren; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.klimafaktoren (
    zip character varying(5),
    d_02_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2008 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2009 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2010 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2011 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2012 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2013 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2014 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2015 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2016 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2017 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2018 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2019 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2020 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_02_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_03_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_04_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_05_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_06_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_07_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_08_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_09_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_10_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_11_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_12_2021 character varying(4) DEFAULT 1 NOT NULL,
    d_01_2022 character varying(4) DEFAULT 1 NOT NULL
);


ALTER TABLE public.klimafaktoren OWNER TO main;

--
-- Name: rechnungen; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.rechnungen (
    id integer NOT NULL,
    benutzer_id integer NOT NULL,
    empfaenger_zeile_1 character varying,
    empfaenger_zeile_2 character varying,
    strasse character varying(100) NOT NULL,
    plz character varying,
    ort character varying,
    uid uuid NOT NULL
);


ALTER TABLE public.rechnungen OWNER TO main;

--
-- Name: rechnungen_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.rechnungen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rechnungen_id_seq OWNER TO main;

--
-- Name: rechnungen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.rechnungen_id_seq OWNED BY public.rechnungen.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.tokens (
    id integer NOT NULL,
    token character varying(36) NOT NULL,
    user_id integer NOT NULL,
    date_created timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    times_used integer DEFAULT 0 NOT NULL,
    permissions integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.tokens OWNER TO main;

--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tokens_id_seq OWNER TO main;

--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: zip_codes; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.zip_codes (
    id integer NOT NULL,
    zip character varying(5) NOT NULL,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL
);


ALTER TABLE public.zip_codes OWNER TO main;

--
-- Name: zip_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.zip_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zip_codes_id_seq OWNER TO main;

--
-- Name: zip_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.zip_codes_id_seq OWNED BY public.zip_codes.id;


--
-- Name: TokenUsage id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."TokenUsage" ALTER COLUMN id SET DEFAULT nextval('public."TokenUsage_id_seq"'::regclass);


--
-- Name: VerbrauchsausweisWohnen id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisWohnen" ALTER COLUMN id SET DEFAULT nextval('public."VerbrauchsausweisWohnen_id_seq"'::regclass);


--
-- Name: adressen id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.adressen ALTER COLUMN id SET DEFAULT nextval('public.adressen_id_seq'::regclass);


--
-- Name: anteilshaber id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.anteilshaber ALTER COLUMN id SET DEFAULT nextval('public.anteilshaber_id_seq'::regclass);


--
-- Name: bedarfsausweis_wohnen id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.bedarfsausweis_wohnen ALTER COLUMN id SET DEFAULT nextval('public.bedarfsausweis_wohnen_id_seq'::regclass);


--
-- Name: benutzer id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.benutzer ALTER COLUMN id SET DEFAULT nextval('public.benutzer_id_seq'::regclass);


--
-- Name: documenttemplates id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttemplates ALTER COLUMN id SET DEFAULT nextval('public.documenttemplates_id_seq'::regclass);


--
-- Name: documenttypes id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttypes ALTER COLUMN id SET DEFAULT nextval('public.documenttypes_id_seq'::regclass);


--
-- Name: gebaeude_bilder id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_bilder ALTER COLUMN id SET DEFAULT nextval('public.gebaeude_bilder_id_seq'::regclass);


--
-- Name: gebaeude_plaene id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_plaene ALTER COLUMN id SET DEFAULT nextval('public.gebaeude_plaene_id_seq'::regclass);


--
-- Name: gebaeude_stammdaten id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_stammdaten ALTER COLUMN id SET DEFAULT nextval('public.gebaeude_stammdaten_id_seq'::regclass);


--
-- Name: rechnungen id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.rechnungen ALTER COLUMN id SET DEFAULT nextval('public.rechnungen_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: zip_codes id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.zip_codes ALTER COLUMN id SET DEFAULT nextval('public.zip_codes_id_seq'::regclass);


--
-- Data for Name: Postleitzahlen; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public."Postleitzahlen" (id) FROM stdin;
\.


--
-- Data for Name: TokenUsage; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public."TokenUsage" (id, token_id, date, resource_hash, payload_length, response_length, response_success, response_code) FROM stdin;
\.


--
-- Data for Name: VerbrauchsausweisGewerbe; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public."VerbrauchsausweisGewerbe" (id, uid, gebaeude_stammdaten_id, rechnungen_id, benutzer_id) FROM stdin;
\.


--
-- Data for Name: VerbrauchsausweisWohnen; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public."VerbrauchsausweisWohnen" (id, uid, gebaeude_stammdaten_id, benutzer_id, rechnungen_id, erstellungsdatum, ausstellgrund, registriernummer, erledigt, baujahr_heizung, zusaetzliche_heizquelle, brennstoff_1, einheit_1, brennstoff_2, einheit_2, startdatum, enddatum, verbrauch_1, verbrauch_2, verbrauch_3, verbrauch_4, verbrauch_5, verbrauch_6, warmwasser_enthalten, anteil_warmwasser_1, anteil_warmwasser_2) FROM stdin;
\.


--
-- Data for Name: adressen; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.adressen (id, benutzer_id, empfaenger_zeile_1, empfaenger_zeile_2, strasse, plz, ort, geolocation, uid) FROM stdin;
\.


--
-- Data for Name: anteilshaber; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.anteilshaber (id, benutzer_id, gebaeude_id, rolle, privilegien, uid) FROM stdin;
\.


--
-- Data for Name: bedarfsausweis_wohnen; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.bedarfsausweis_wohnen (id, uid, gebaeude_stammdaten_id, benutzer_id, rechnungen_id, ausweisart, erstellungsdatum, ausstellgrund, registriernummer, erledigt, saniert, baujahr, einheiten, wohnflaeche, keller_beheizt, dachgeschoss_beheizt, lueftungskonzept, leerstand, versorgungssysteme, fenster_dach, energiequelle_2_nutzung, daemmung, anzahl_vollgeschosse, geschosshoehe, anzahl_gauben, breite_gauben, masse_a, masse_b, masse_c, masse_d, masse_e, masse_f, fensterflaeche_so_sw, fensterflaeche_nw_no, aussenwandflaeche_unbeheizt, dachflaeche, deckenflaeche, dach_u_wert, decke_u_wert, aussenwand_flaeche, aussenwand_u_wert, fussboden_flaeche, fussboden_u_wert, volumen, dicht, fenster_flaeche_1, fenster_art_1, fenster_flaeche_2, fenster_art_2, dachfenster_flaeche, dachfenster_art, haustuer_flaeche, haustuer_art, dach_bauart, decke_bauart, dach_daemmung, decke_daemmung, aussenwand_daemmung, boden_daemmung, aussenwand_bauart, boden_bauart, warmwasser_verteilung, warmwasser_speicherung, warmwasser_erzeugung, heizung_zentral, heizung_verteilung, heizung_speicherung, waerme_erzeugung_heizung, anteil_zusatzheizung, kollektor_flaeche, vanw_stromverbrauch_enthalten, wird_gekuehlt) FROM stdin;
\.


--
-- Data for Name: benutzer; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.benutzer (id, name, vorname, email, passwort, profilbild, benutzer_adresse_id, rechnung_adresse_id, versand_adresse_id, uid) FROM stdin;
\.


--
-- Data for Name: documenttemplates; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.documenttemplates (id, name, shortdescription, longdescription, user_id, is_private, documenttype, filename, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documenttypes; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.documenttypes (id, name, shortdescription, longdescription) FROM stdin;
\.


--
-- Data for Name: gebaeude_bilder; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.gebaeude_bilder (id, gebaeude_stammdaten_id, kategorie, uid) FROM stdin;
\.


--
-- Data for Name: gebaeude_plaene; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.gebaeude_plaene (id, gebaeude_stammdaten_id, uid) FROM stdin;
\.


--
-- Data for Name: gebaeude_stammdaten; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.gebaeude_stammdaten (id, uid, benutzer_id, gebaeude_adresse_id, gebaeudetyp, gebaeudeteil, baujahr_gebaeude, baujahr_heizung, baujahr_klima, einheiten, flaeche, saniert, keller, dachgeschoss, lueftung, kuehlung, leerstand) FROM stdin;
\.


--
-- Data for Name: klimafaktoren; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.klimafaktoren (zip, d_02_2008, d_03_2008, d_04_2008, d_05_2008, d_06_2008, d_07_2008, d_08_2008, d_09_2008, d_10_2008, d_11_2008, d_12_2008, d_01_2009, d_02_2009, d_03_2009, d_04_2009, d_05_2009, d_06_2009, d_07_2009, d_08_2009, d_09_2009, d_10_2009, d_11_2009, d_12_2009, d_01_2010, d_02_2010, d_03_2010, d_04_2010, d_05_2010, d_06_2010, d_07_2010, d_08_2010, d_09_2010, d_10_2010, d_11_2010, d_12_2010, d_01_2011, d_02_2011, d_03_2011, d_04_2011, d_05_2011, d_06_2011, d_07_2011, d_08_2011, d_09_2011, d_10_2011, d_11_2011, d_12_2011, d_01_2012, d_02_2012, d_03_2012, d_04_2012, d_05_2012, d_06_2012, d_07_2012, d_08_2012, d_09_2012, d_10_2012, d_11_2012, d_12_2012, d_01_2013, d_02_2013, d_03_2013, d_04_2013, d_05_2013, d_06_2013, d_07_2013, d_08_2013, d_09_2013, d_10_2013, d_11_2013, d_12_2013, d_01_2014, d_02_2014, d_03_2014, d_04_2014, d_05_2014, d_06_2014, d_07_2014, d_08_2014, d_09_2014, d_10_2014, d_11_2014, d_12_2014, d_01_2015, d_02_2015, d_03_2015, d_04_2015, d_05_2015, d_06_2015, d_07_2015, d_08_2015, d_09_2015, d_10_2015, d_11_2015, d_12_2015, d_01_2016, d_02_2016, d_03_2016, d_04_2016, d_05_2016, d_06_2016, d_07_2016, d_08_2016, d_09_2016, d_10_2016, d_11_2016, d_12_2016, d_01_2017, d_02_2017, d_03_2017, d_04_2017, d_05_2017, d_06_2017, d_07_2017, d_08_2017, d_09_2017, d_10_2017, d_11_2017, d_12_2017, d_01_2018, d_02_2018, d_03_2018, d_04_2018, d_05_2018, d_06_2018, d_07_2018, d_08_2018, d_09_2018, d_10_2018, d_11_2018, d_12_2018, d_01_2019, d_02_2019, d_03_2019, d_04_2019, d_05_2019, d_06_2019, d_07_2019, d_08_2019, d_09_2019, d_10_2019, d_11_2019, d_12_2019, d_01_2020, d_02_2020, d_03_2020, d_04_2020, d_05_2020, d_06_2020, d_07_2020, d_08_2020, d_09_2020, d_10_2020, d_11_2020, d_12_2020, d_01_2021, d_02_2021, d_03_2021, d_04_2021, d_05_2021, d_06_2021, d_07_2021, d_08_2021, d_09_2021, d_10_2021, d_11_2021, d_12_2021, d_01_2022) FROM stdin;
\.


--
-- Data for Name: rechnungen; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.rechnungen (id, benutzer_id, empfaenger_zeile_1, empfaenger_zeile_2, strasse, plz, ort, uid) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.tokens (id, token, user_id, date_created, last_used, times_used, permissions) FROM stdin;
\.


--
-- Data for Name: zip_codes; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.zip_codes (id, zip, city, state) FROM stdin;
\.


--
-- Name: TokenUsage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public."TokenUsage_id_seq"', 1, false);


--
-- Name: VerbrauchsausweisWohnen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public."VerbrauchsausweisWohnen_id_seq"', 1, false);


--
-- Name: adressen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.adressen_id_seq', 1, false);


--
-- Name: anteilshaber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.anteilshaber_id_seq', 1, false);


--
-- Name: bedarfsausweis_wohnen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.bedarfsausweis_wohnen_id_seq', 1, false);


--
-- Name: benutzer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.benutzer_id_seq', 1, false);


--
-- Name: documenttemplates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.documenttemplates_id_seq', 1, false);


--
-- Name: documenttypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.documenttypes_id_seq', 1, false);


--
-- Name: gebaeude_bilder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.gebaeude_bilder_id_seq', 1, false);


--
-- Name: gebaeude_plaene_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.gebaeude_plaene_id_seq', 1, false);


--
-- Name: gebaeude_stammdaten_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.gebaeude_stammdaten_id_seq', 1, false);


--
-- Name: rechnungen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.rechnungen_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.tokens_id_seq', 1, false);


--
-- Name: zip_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.zip_codes_id_seq', 1, false);


--
-- Name: documenttemplates PK_DOCUMENTTEMPLATES; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttemplates
    ADD CONSTRAINT "PK_DOCUMENTTEMPLATES" PRIMARY KEY (id);


--
-- Name: documenttypes PK_DOCUMENTTYPES; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttypes
    ADD CONSTRAINT "PK_DOCUMENTTYPES" PRIMARY KEY (id);


--
-- Name: tokens PK_TOKENS; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT "PK_TOKENS" PRIMARY KEY (id);


--
-- Name: TokenUsage PK_TOKEN_USAGE; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."TokenUsage"
    ADD CONSTRAINT "PK_TOKEN_USAGE" PRIMARY KEY (id);


--
-- Name: Postleitzahlen Postleitzahlen_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."Postleitzahlen"
    ADD CONSTRAINT "Postleitzahlen_pkey" PRIMARY KEY (id);


--
-- Name: VerbrauchsausweisGewerbe VerbrauchsausweisGewerbe_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisGewerbe"
    ADD CONSTRAINT "VerbrauchsausweisGewerbe_pkey" PRIMARY KEY (id);


--
-- Name: VerbrauchsausweisWohnen VerbrauchsausweisWohnen_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisWohnen"
    ADD CONSTRAINT "VerbrauchsausweisWohnen_pkey" PRIMARY KEY (id);


--
-- Name: adressen adressen_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.adressen
    ADD CONSTRAINT adressen_pkey PRIMARY KEY (id);


--
-- Name: anteilshaber anteilshaber_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.anteilshaber
    ADD CONSTRAINT anteilshaber_pkey PRIMARY KEY (id);


--
-- Name: bedarfsausweis_wohnen bedarfsausweis_wohnen_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.bedarfsausweis_wohnen
    ADD CONSTRAINT bedarfsausweis_wohnen_pkey PRIMARY KEY (id);


--
-- Name: benutzer benutzer_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_pkey PRIMARY KEY (id);


--
-- Name: gebaeude_bilder gebaeude_bilder_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_bilder
    ADD CONSTRAINT gebaeude_bilder_pkey PRIMARY KEY (id);


--
-- Name: gebaeude_plaene gebaeude_plaene_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_plaene
    ADD CONSTRAINT gebaeude_plaene_pkey PRIMARY KEY (id);


--
-- Name: gebaeude_stammdaten gebaeude_stammdaten_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_stammdaten
    ADD CONSTRAINT gebaeude_stammdaten_pkey PRIMARY KEY (id);


--
-- Name: rechnungen rechnungen_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.rechnungen
    ADD CONSTRAINT rechnungen_pkey PRIMARY KEY (id);


--
-- Name: benutzer_email_idx; Type: INDEX; Schema: public; Owner: main
--

CREATE UNIQUE INDEX benutzer_email_idx ON public.benutzer USING btree (email);


--
-- Name: benutzer_uid_key; Type: INDEX; Schema: public; Owner: main
--

CREATE UNIQUE INDEX benutzer_uid_key ON public.benutzer USING btree (uid);


--
-- Name: gebaeude_bilder_uid_key; Type: INDEX; Schema: public; Owner: main
--

CREATE UNIQUE INDEX gebaeude_bilder_uid_key ON public.gebaeude_bilder USING btree (uid);


--
-- Name: gebaeude_stammdaten_uid_key; Type: INDEX; Schema: public; Owner: main
--

CREATE UNIQUE INDEX gebaeude_stammdaten_uid_key ON public.gebaeude_stammdaten USING btree (uid);


--
-- Name: VerbrauchsausweisGewerbe VerbrauchsausweisGewerbe_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisGewerbe"
    ADD CONSTRAINT "VerbrauchsausweisGewerbe_benutzer_id_fkey" FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: VerbrauchsausweisGewerbe VerbrauchsausweisGewerbe_gebaeude_stammdaten_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisGewerbe"
    ADD CONSTRAINT "VerbrauchsausweisGewerbe_gebaeude_stammdaten_id_fkey" FOREIGN KEY (gebaeude_stammdaten_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: VerbrauchsausweisGewerbe VerbrauchsausweisGewerbe_rechnungen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisGewerbe"
    ADD CONSTRAINT "VerbrauchsausweisGewerbe_rechnungen_id_fkey" FOREIGN KEY (rechnungen_id) REFERENCES public.rechnungen(id);


--
-- Name: VerbrauchsausweisWohnen VerbrauchsausweisWohnen_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisWohnen"
    ADD CONSTRAINT "VerbrauchsausweisWohnen_benutzer_id_fkey" FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: VerbrauchsausweisWohnen VerbrauchsausweisWohnen_gebaeude_stammdaten_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisWohnen"
    ADD CONSTRAINT "VerbrauchsausweisWohnen_gebaeude_stammdaten_id_fkey" FOREIGN KEY (gebaeude_stammdaten_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: VerbrauchsausweisWohnen VerbrauchsausweisWohnen_rechnungen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."VerbrauchsausweisWohnen"
    ADD CONSTRAINT "VerbrauchsausweisWohnen_rechnungen_id_fkey" FOREIGN KEY (rechnungen_id) REFERENCES public.rechnungen(id);


--
-- Name: adressen adressen_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.adressen
    ADD CONSTRAINT adressen_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: anteilshaber anteilshaber_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.anteilshaber
    ADD CONSTRAINT anteilshaber_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: anteilshaber anteilshaber_gebaeude_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.anteilshaber
    ADD CONSTRAINT anteilshaber_gebaeude_id_fkey FOREIGN KEY (gebaeude_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: bedarfsausweis_wohnen bedarfsausweis_wohnen_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.bedarfsausweis_wohnen
    ADD CONSTRAINT bedarfsausweis_wohnen_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: bedarfsausweis_wohnen bedarfsausweis_wohnen_gebaeude_stammdaten_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.bedarfsausweis_wohnen
    ADD CONSTRAINT bedarfsausweis_wohnen_gebaeude_stammdaten_id_fkey FOREIGN KEY (gebaeude_stammdaten_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: bedarfsausweis_wohnen bedarfsausweis_wohnen_rechnungen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.bedarfsausweis_wohnen
    ADD CONSTRAINT bedarfsausweis_wohnen_rechnungen_id_fkey FOREIGN KEY (rechnungen_id) REFERENCES public.rechnungen(id);


--
-- Name: documenttemplates benutzer_fk; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttemplates
    ADD CONSTRAINT benutzer_fk FOREIGN KEY (user_id) REFERENCES public.benutzer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: benutzer benutzer_rechnung_adresse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_rechnung_adresse_id_fkey FOREIGN KEY (rechnung_adresse_id) REFERENCES public.adressen(id);


--
-- Name: benutzer besteller_adressen_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT besteller_adressen_id_fkey1 FOREIGN KEY (benutzer_adresse_id) REFERENCES public.adressen(id);


--
-- Name: benutzer besteller_adressen_id_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT besteller_adressen_id_fkey2 FOREIGN KEY (versand_adresse_id) REFERENCES public.adressen(id);


--
-- Name: documenttemplates documenttypes_fk; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.documenttemplates
    ADD CONSTRAINT documenttypes_fk FOREIGN KEY (documenttype) REFERENCES public.documenttypes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tokens fk_benutzer_tokens_user_id; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT fk_benutzer_tokens_user_id FOREIGN KEY (user_id) REFERENCES public.benutzer(id);


--
-- Name: TokenUsage fk_tokens_token_usage_token_id; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public."TokenUsage"
    ADD CONSTRAINT fk_tokens_token_usage_token_id FOREIGN KEY (token_id) REFERENCES public.tokens(id);


--
-- Name: gebaeude_bilder gebaeude_bilder_gebaeude_stammdaten_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_bilder
    ADD CONSTRAINT gebaeude_bilder_gebaeude_stammdaten_id_fkey FOREIGN KEY (gebaeude_stammdaten_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: gebaeude_plaene gebaeude_plaene_gebaeude_stammdaten_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_plaene
    ADD CONSTRAINT gebaeude_plaene_gebaeude_stammdaten_id_fkey FOREIGN KEY (gebaeude_stammdaten_id) REFERENCES public.gebaeude_stammdaten(id);


--
-- Name: gebaeude_stammdaten gebaeude_stammdaten_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_stammdaten
    ADD CONSTRAINT gebaeude_stammdaten_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- Name: gebaeude_stammdaten gebaeude_stammdaten_gebaeude_adresse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.gebaeude_stammdaten
    ADD CONSTRAINT gebaeude_stammdaten_gebaeude_adresse_id_fkey FOREIGN KEY (gebaeude_adresse_id) REFERENCES public.adressen(id);


--
-- Name: rechnungen rechnungen_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.rechnungen
    ADD CONSTRAINT rechnungen_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id);


--
-- PostgreSQL database dump complete
--

